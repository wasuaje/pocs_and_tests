#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#   Celu.py
#       
#   2010 Manuel Argüelles <manu.argue(at)gmail.com>
#
#       
#   This file is part of smsWeb v0.1.
#
#   smsWeb v0.1 is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   smsWeb v0.1 is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with smsWeb v0.1.  If not, see <http://www.gnu.org/licenses/>.


from AlToque import AlToque
from Excepciones import EnvioError
import urllib2


class Celular:
    
    def __init__(self, nombre):
        self.nombre = nombre
        self.sms = []
        self.MAX_CHAR = 110
        self.cantidadSms = 0
    
    def escribirSms(self, mensaje):
        self.sms = self.dividirSms(mensaje)
        self.cantidadSms = len(self.sms)
        
    
    def enviarSms(self, numDestino, empresa):
        central = AlToque()
        try:
            print '[i] Conectando...'
            central.iniciarConexion()
        except (urllib2.HTTPError, urllib2.URLError):
            print '[!] No se pudo conectar con el servidor'
            return 1
        else:
            print '[i] Conexion establecida'
            
        for i in range(self.cantidadSms):
            print '[i] Enviando mensaje '+str(i+1)+' de '+str(self.cantidadSms)+'...'
            central.escribirDatos(empresa, numDestino, self.nombre, self.sms[i])
            try:
                central.enviarDatos()
            except (urllib2.HTTPError, urllib2.URLError):
                print '[!] El servidor no responde'
                break
            except EnvioError:
                print '[!] No se pudo enviar el mensaje. Verifique los datos'
                break
        central.cerrarConexion() #necesario???
        
        
    
    def dividirSms(self, mensaje):
        """Divide un mensaje en una lista de sms con MAX_CHAR caracteres"""
        smsList = []
        cantidadSms = len(mensaje) / self.MAX_CHAR + 1
        for i in range(cantidadSms):
            smsList.append(mensaje[:self.MAX_CHAR])
            mensaje = mensaje[self.MAX_CHAR:]
        return smsList
    

