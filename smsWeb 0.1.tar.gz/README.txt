-------------------------------------
----------* smsWeb v0.1 *------------
-------------------------------------
------ Manuel Argüelles - 2010 ------
------ manu.argue(at)gmail.com ------
-------------------------------------
-- este programa es software libre --
------ bajo licencia GNU GPL v3 -----
-------------------------------------


Indice:
    1)¿Qué es smsWeb v0.1?
    2)Prestadoras disponibles
    3)Cómo usarlo
    4)Dependencias
    5)Acerca del autor
    6)Licencia


1)¿Qué es smsWeb v0.1?
    smsWeb v0.1 permite enviar mensajes SMS desde la consola a celulares de diferentes
    empresas, que tengan habilitado el servicio de recepcion de SMS por web.
    El envio de los mensajes se hace a traves de la web Altoque.com.
    

2)Prestadoras disponibles:
    Claro, Movistar, Nextel, Personal.


3)Cómo usarlo:
    Para iniciar el programa ejecute el archivo "Principal.py".
    En GNU/Linux puede hacerlo de la forma ./Principal.py o python Principal.py
   
    Cuando el programa se inicie se le pediran los datos necesarios para enviar
    el SMS. En orden, estos son:
        
        *Empresa -> nombre de la empresa del celular destino. Si no conoce la empresa,
                   puede dejar el campo en blanco y se tratara de encontrar la 
                   empresa. (De esta forma no se garatiza la entrega del mensaje)
        
        *Celular -> debe ser ingresado de la forma xxx-XXXX, donde los primeros
                   numeros son la caracteristicas (sin cero), seguidos por un
                   guion medio, y los numeros del celular (sin 15).
                   Ejemplo: el celular 0291 15 4740266 se escribe -> 291-4740266
        
        *Nombre ->  su nombre. Aparecera en la cabecera del SMS. Puede dejar este
                   campo sin llenar y se enviará con nombre por omisión "yo".
        
        *Mensaje -> mensaje a enviar. Si el mensaje supera los 110 caracteres,
                   sera enviado en varios mensajes.
    
    Durante el envío del SMS, se le informaŕa sobre el estado de cada etapa de envío.
    Si la conexion falla o el mensaje no puede ser enviado, el programa terminará
    con el aviso de error correspondiente.
    
    Nota: Para detener en cualquier momento la ejecucion del programa se debe
    apretar Ctrl+C o Ctrl+D.


4)Dependencias:
    Para poder correr el programa se necesita tener instalado:
        python >= 2.5
        libreria ClientForm (paquete python-clientform en Debian)
        libreria urllib2 (forma parte de los módulos de python)


5)Acerca del autor:
    Manuel Argüelles - Argentina
    mail/msn = manu.argue(at)gmail.com


6)Licencia:
    Todas las partes que componen smsWeb v0.1 estan bajo GNU General Public License v3.
    En el archivo "Licencia.txt" se encuentra una copia de la misma.
  
    



