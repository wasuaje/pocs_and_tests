#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#   Principal.py
#       
#   2010 Manuel Argüelles <manu.argue(at)gmail.com>
#
#       
#   This file is part of smsWeb v0.1.
#
#   smsWeb v0.1 is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   smsWeb v0.1 is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with smsWeb v0.1.  If not, see <http://www.gnu.org/licenses/>.


from Celular import Celular
from Consola import Consola
import sys




def main():
    textoBienvenida = '\nsmsWeb v0.1\nManuel Argüelles 2010 (GNU GPL v3)\n'
    consola = Consola(textoBienvenida)
    consola.loop()
    celular = Celular(consola.nombre)
    celular.escribirSms(consola.mensaje)
    celular.enviarSms(consola.cel,consola.empresa)


if __name__ == '__main__':
    try:
        main()
    except (KeyboardInterrupt, EOFError):
        print ''
        sys.exit()

