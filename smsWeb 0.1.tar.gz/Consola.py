#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#   Console.py
#       
#   2010 Manuel Argüelles <manu.argue(at)gmail.com>
#
#       
#   This file is part of smsWeb v0.1.
#
#   smsWeb v0.1 is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   smsWeb v0.1 is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with smsWeb v0.1.  If not, see <http://www.gnu.org/licenses/>.


class Consola:
    
    def __init__(self,texto):
        self.listaEmpresa = ['claro','movistar','nextel','personal']
        self.nombreDefault = 'yo'
        self.prompt = '>> '
        self.alert = '[!] '
        self.info = '[i] '
        print texto
        
    
    def loop(self):
           
        while 1:
            self.empresa = raw_input(self.prompt+'Empresa: ').lower().strip()
            if self.empresa in self.listaEmpresa:
                break
            elif self.empresa == '':
                self.empresa = 'nose'
                break
            print self.alert + 'La empresa no es valida'

        while 1:
            numCel = raw_input(self.prompt+'Celular: ').strip()
            if numCel.count("-") == 1:
                self.cel = self.parseCel(numCel)
                if (self.cel[0].isdigit() and self.cel[1].isdigit()):
                    break
            print self.alert + 'El formato del celular debe ser xxx-XXX'
        
        self.nombre = raw_input(self.prompt+'Nombre: ').strip()
        self.nombre = self.nombre.replace(' ','_')
        if self.nombre == '':
            self.nombre = self.nombreDefault

        self.mensaje = raw_input(self.prompt+'Mensaje: ').strip()
    
    
    def parseCel(self, celular):
        caracteristica = celular[:celular.find("-")].strip()
        numero = celular[celular.find("-")+1:].strip()
        return (caracteristica, numero)
    

