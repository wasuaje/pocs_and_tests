#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#   Altoque.py
#       
#   2010 Manuel Argüelles <manu.argue(at)gmail.com>
#
#       
#   This file is part of smsWeb v0.1.
#
#   smsWeb v0.1 is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#   smsWeb v0.1 is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with smsWeb v0.1.  If not, see <http://www.gnu.org/licenses/>.



import urllib2
import ClientForm
from Excepciones import EnvioError


class AlToque:
    
    def __init__(self):
        self.url = 'http://www.altoque.com/sms/mensajes_al_celular.php'
        self.empresa = {'claro':'1',
                        'movistar':'2',
                        'personal':'3',
                        'nextel':'4',
                        'nose':'5'}
        self.camposForm = ['empre','tel','tel1','mail','mensaje_tmp']
        
    
    def iniciarConexion(self):
        self.respForm = urllib2.urlopen(urllib2.Request(self.url))
        self.formulario = ClientForm.ParseResponse(self.respForm,
                            backwards_compat=False)[0]
        self.formulario.set_all_readonly(False)
    
    
    def escribirDatos(self, empresa, numDestino, nombre, sms):
        nombre = nombre + '@yo.com'
        datos = [[self.empresa[empresa]], numDestino[0],
                numDestino[1], nombre, sms]
        
        for i,j in zip(self.camposForm, datos):
            self.formulario[i] = j
        self.formulario['mensaje'] = sms
        self.formulario['mensaje_hidden'] = sms
    
    
    def enviarDatos(self):
        self.respEnvio = urllib2.urlopen(self.formulario.click())
        self.htmlEnvio = self.respEnvio.read()
        if self.htmlEnvio.count('No se pudo enviar'):
            raise EnvioError
        elif self.htmlEnvio.count('su <b>mensaje</b> se ha enviado con'):
            print '[i] Mensaje enviado!'

    
    def cerrarConexion(self):
        self.respForm.close()
        self.respEnvio.close()
    
