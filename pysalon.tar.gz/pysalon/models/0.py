from gluon.storage import Storage
settings = Storage()

settings.migrate = True
settings.title = 'Sistema para salones de belleza'
settings.subtitle = 'Salon v1.00'
settings.author = 'Wasuaje'
settings.author_email = 'wasuaje@hotmail.com'
settings.keywords = ''
settings.description = ''
settings.layout_theme = 'Default'
settings.database_uri = 'sqlite://storage.sqlite'
settings.security_key = 'd7c965e8-0685-477a-baae-087e7372943f'
settings.email_server = 'localhost'
settings.email_sender = 'you@example.com'
settings.email_login = ''
settings.login_method = 'local'
settings.login_config = ''
settings.googlemap_key = 'ABQIAAAAT5em2PdsvF3z5onQpCqv0RTpH3CbXHjuCVmaTc5MkkU4wO1RRhQHEAKj2S9L72lEMpvNxzLVfJt6cg'
settings.impuesto=12.00

