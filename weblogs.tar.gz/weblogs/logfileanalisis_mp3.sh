
PATH=/usr/local/nginx/logs
#FILES="access-mp3.log.1 www-eluniversal-access.log.1 static-elunivesal-access.log.1 static-estampas-access.log.1 www-eluniversal-access.log.1"
FILES="access-mp3.log"
HOSTS="root@204.228.236.13 root@204.228.236.17"

#copia local 
for fl in $FILES
 do
  /bin/cp $PATH/$fl.1 wb01$fl.1
 done

#copa remot
for ht in $HOSTS
do 
 for fl in $FILES
 do
  echo $ht:$PATH/$fl ./$ht$fl
  /usr/bin/scp $ht:$PATH/$fl ./$ht$fl.1
 done
done

for fh in $(/bin/ls *.log.1)
do
 /bin/cat $fh >> bigfile.log
 /bin/rm -f $fh
done

if [ -f bigfile.log ]; then
 /bin/cat  bigfile.log | /usr/local/bin/goaccess -a > "reporte.html"
else
 echo "no se encontro bigfile"
fi

from=sysadmin@eluniversal.com
to=wasuaje@eluniversal.com
subject="Analisis de descargas mp3"
message=$(/bin/cat reporte.html)
(
echo "From: ${from}";
echo "To: ${to}";
echo "Subject: ${subject}";
echo "Content-Type: text/html";
echo "MIME-Version: 1.0";
echo "";
echo "${message}";
) | /usr/sbin/sendmail -t

#/bin/rm -f bigfile.log

