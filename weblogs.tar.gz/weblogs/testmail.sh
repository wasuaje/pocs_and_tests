#!/bin/bash
from=sysadmin@eluniversal.com
to="wasuaje@eluniversal.com,wasuaje@hotmail.com"
subject="Analisis de estampas.com"
message=$(/bin/cat reporte.html)
(
echo "From: ${from}";
echo "To: ${to}";
echo "Subject: ${subject}";
echo "Content-Type: text/html";
echo "MIME-Version: 1.0";
echo "";
echo "${message}";
) | /usr/sbin/sendmail -t




