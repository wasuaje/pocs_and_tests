# -*- coding: utf-8 -*-
import medical_inpatient
